<template>
  <div class="page-classify">
    <h1>分类页面</h1>
  </div>
</template>
<script>
export default {
  name: 'Classfiy'
}
</script>
