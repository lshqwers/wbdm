<template>
    <div class="page-search-result">
        <h1>搜索结果页</h1>
    </div>
</template>
<script>
export default {
  name: 'SearchResult'
}
</script>
