 <template>
  <div class="page-end">
    <div class="nav_layout">
     <div class="left">
       <router-link to="/Home" style="text-decrotion:none">
         <img src="../../../public/tupi/arrow.png" alt="">
       </router-link>
     </div>
     <div class="rig">完结</div>
     <div class="rig-box"></div>
    </div>
  <div class="bar">
    <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/22/2084322240_mGV6SQRx.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                渡灵Guarding
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
    <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_kzPR1PMX.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                秋语落风—山寨大哥成长记
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
    <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_C0jKJkU0.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">校园</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                飓风13号
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
    <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_Sjx51dYB.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">奇幻</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                秋语落风—山寨大哥成长记
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
     <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_ZTFdJpZS.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                貘香
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
    <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/02/07/6391218420_5ziHWTki.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">悬疑</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                海中世
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
    <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/02/07/6068730587_jC65voOa.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                特工皇妃楚乔传
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
    <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/03/07/6348066216_hH3yGTsf.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">动作</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                猎鸦
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
     <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/02/07/5657589144_8sjtZY5A.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">古风</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
              白鹤三绝
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
     <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_q7gyJph8.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                布拉格小夜曲
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
      <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_ujNABQac.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                千灯录
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
      <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_oGPAXrrA.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                禁魔启示录
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
      <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_Ze3ufnt8.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                无名分浪漫
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
      <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_33EcigMK.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">奇幻</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                距离1400光年
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
      <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_4Bh9oO1w.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                西京梦华
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
       <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_x0qG3q76.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                一往
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
       <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/02/11/1296720452_KmkBApPF.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                滚蛋吧肿瘤君！
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
       <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/08/21/3471934934_q7gyJph8.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
                布拉格小夜曲
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
       <div class="end_list_box scroll">
    <div class="end_list_item">
        <div class="comic_cover_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/04/17/2526032835_qp9lDwjE.jpg" alt="">
          <div class="comic_cover_info">
            <div class="comic_cover_titleBox">
              <div class="comic_cover_label">
              <div class="works_label label_bg_orange">
                <span class="works_label_text">恋爱</span>
              </div>
              </div>
              <div class="comic_cover_title" style="font-size: 16px;">
              外公芳龄38
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
  </div>
  </div>
</template>
<script>
// 把请求的接口数据解构出来
import { getIndexweek, getIndexend } from '../../api/cartoon'
export default {
  name: 'End',
  data () {
    return {
      shuju: []
    }
  },
  methods: {
    // getIndexend () { // 定义一个方法
    //   getIndexend().then(res => {
    //     if (res.code === 200) {
    //       this.shuju = res.data.data.ending_works_list
    //       console.log(res)
    //     } else {
    //       alert('404')
    //     }
    //   }).catch(err => {
    //     alert(err, '网络请求错误')
    //   })
    // },
    getIndexend () {
      getIndexend().then(res => {
        console.log(111)
        console.log(res.data)
      })
    },
    getIndexweek () {
      getIndexweek().then(res => {
        console.log(res)
      })
    }
  },
  // mounted不能放在methods的方法中
  created () {
    this.getIndexend() // 一定要使用this否则,获取不到数据
    this.getIndexweek()
  }
}
</script>
<style lang="scss">
.page-end {
  height: 100%;
  display: flex;
  flex-direction: column;
  .nav_layout {
    width: 100%;
    height: 44px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .left img {
      width: 44px;
      height: 44px;
    }
    .rig {
      font-size: 18px;
      color: #333;
    }
    .rig-box {
      width: 44px;
      height: 44px;
    }
  }
  .end_list_box .scroll {
    overflow: auto;
    flex: 1;
  }
  .end_list_item {
    .comic_cover_container {
      margin-bottom: 8px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      img {
        width: 100%;
        height: 211px;
      }
      .comic_cover_info {
        width: 100%;
        height: 29px;
        margin: 0 8px 0 0;
      }
      .comic_cover_titleBox {
        margin: 8px;
        display: flex;
        align-items: center;
      }
    }
  }
  .comic_cover_label {
    margin-right: 4px;
  }
  .label_bg_orange {
    background: #fc7933;
    border-radius: 2px;
    width: 32px;
    height: 16px;
    line-height: 16px;
    border: 1px solid transparent;
    box-sizing: border-box;
    font-size: 10px;
    color: #efefef;
    text-align: center;
  }
  .works_label_text {
    width: 24px;
    height: 16px;
  }
  .comic_cover_title {
    color: #666666;
  }
  .bar {
    height: 100%;
    overflow-y: auto;
  }
}
</style>
