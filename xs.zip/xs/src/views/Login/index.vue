<template>
    <div class="page-login">
        <h1>登入页</h1>
    </div>
</template>
<script>
export default {
  name: 'Login'
}
</script>
