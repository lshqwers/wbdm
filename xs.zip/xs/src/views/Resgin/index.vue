<template>
    <div class="page-resgin">
        <h1>登入页面</h1>
    </div>
</template>
<script>
export default {
  name: 'Resgin'
}
