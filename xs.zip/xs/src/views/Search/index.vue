<template>
  <div class="page-search">
    <h1>搜索页面</h1>
  </div>
</template>
<script>
export default {
  name: 'Search'
}
</script>
