<template>
  <div class="page-ranking">
    <div class="rank_list_nav">
      <div class="nav_layout">
        <div class="left">
          <router-link to="/Home" style="text-decrotion:none">
            <img src="../../../public/tupi/arrow.png" alt="">
          </router-link>
      </div>
      <div class="rig">排行榜</div>
          <div class="rig-box"></div>
          </div>
      <div class="rank_list_title">
        <div class="list_title_item" v-for="(item,index) in ranks" :key="item.id" @click="fn1(index)" :class="{active:num === index}">
          {{item.title}}
        </div>
      </div>
    </div>
    <div class="scroll">
      <div class="rank_list_con">
        <div class="comic_horizontal_container">
          <img src="https://img.manhua.weibo.com/hcover/2018/09/12/2660188431_mY991vM7.png" alt="">
          <div class="comic_cover_horizontal_info">
            <div class="comic_cover_horizontal_title">水晶鞋
            </div>
            <div class="comic_cover_horizontal_author">
              <img src="../../../public/tupi/tb.png"/>
              恋爱/校园/剧情
            </div>
             <div class="comic_cover_horizontal_author">
              <img src="../../../public/tupi/xtb.png"/>
              圭古文化
            </div>
          </div>
          <div class="comic_cover_horizontal_rank">
          <img src="../../../public/tupi/tb.png" alt="">
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
// 把对象解构出来
import { getIndexrank } from '../../api/qw.js'
export default {
  name: 'Ranking',
  data () {
    return {
      num: 0,
      ranks: [
        { id: 1, title: '阅读榜' },
        { id: 2, title: '新作榜' },
        { id: 3, title: '综合榜' }
      ],
      rankdata: []
    }
  },
  methods: {
    fn1 (index) {
      this.num = index
    },
    getIndexrank () {
      getIndexrank().then(res => {
        console.log(res)
        if (res.code === 1) {
          this.rankdata = res.data.week
          console.log(res.data.week)
        } else {
          alert('404')
        }
      }).catch(err => {
        alert(err, '网络请求错')
      })
    }
  },
  created () {
    this.getIndexrank()
  }
}
</script>
<style lang="scss">
.page-ranking {
 height: 100%;
 display: flex;
 flex-direction: column;
 .rank_list_nav{
  width: 100%;
  height: 96px;
 }
  .nav_layout {
    width: 100%;
    height: 44px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .left img {
      width: 44px;
      height: 44px;
    }
    .rig {
      font-size: 18px;
      color: #333;
    }
    .rig-box {
      width: 44px;
      height: 44px;
    }
  }
  .rank_list_title{
  margin-bottom: 8px;
  height: 44px;
  line-height: 44px;
  border-bottom: 1px solid  #b3b3b3;
  display: flex;
  justify-content: space-around;
  align-items: center;
  .list_title_item{
  font-size: 14px;
  color: #b3b3b3;
  align-items: center;
  }
  }
  .active {
    border-bottom: 2px solid red;
  }
  .scroll {
   height: 100%;
   overflow-y: auto;
  }
  .comic_horizontal_container {
   padding: 0 16px 16px;
   width: 100%;
   height: 97px;
   display: flex;
   flex-direction: row;
   box-sizing: border-box;
   img {
   width: 144px;
   height: 81px;
   margin: 0px 4px 0px 0px;
   border-radius: 4px;
   }
   .comic_cover_horizontal_info{
   width: 139px;
   height: 81px;
   padding-right: 16px;
   box-sizing: border-box;
   overflow: hidden;
   flex: 1;
   .comic_cover_horizontal_title{
     margin-top: 4px;
     padding-bottom: 4px;
     color: #333;
     line-height: 32px;
     font-size: 16px;
   }
   }
  }
  .comic_cover_horizontal_author{
    font-size: 12px;
    color: #000;
    width: 139px;
    height: 24px;
    // align-items: center;
    display: flex;
    flex-direction: row;
    img{
      width: 16px;
      height: 16px;
    }
  }
  .comic_cover_horizontal_rank{
    img{
    width: 40px;
    height: 45px;
    background-size: 100% 100%;
    margin-top: 19px;
    }
  }
}
</style>
